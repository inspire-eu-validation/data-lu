# Feature references

**Purpose**: Verify that referenced features can be retrieved.

**Prerequisites**

**Test method**

* Verify that any feature reference in an association role is publicly accessible via HTTP, i.e. inspect all relevant properties. If a reference (@xlink:href) has a value that starts with "#", verify that an element with a `gml:id` attribute with the referenced identifier exists in the same document. If the reference starts with "http", verify that a HTTP GET request to the URI retrieves an XML document. Otherwise report [brokenLink](#brokenLink).

This data theme currently has the following association roles:

* ManagementRestrictionOrRegulationZone.[relatedZone](#relatedZone) : ManagementRestrictionOrRegulationZone
* ManagementRestrictionOrRegulationZone.[plan](#plan) : base2:DocumentCitation
* ManagementRestrictionOrRegulationZone.[legalBasis](#legalBasis) : base2:LegislationCitation

**Reference(s)**: 

* [TG DS Template](./README.md#ref_TG_DS_tmpl) IR requirement Article 4 (2)

**Test type**: Automated

**Notes**

## Messages

Identifier  |  Message text (parameters start with '$')
---------------------------------------------------------- | -------------------------------------------------------------------------
brokenLink <a name="brokenLink"/>  |  XML document '$filename', $featureType '$gmlid': The property '$propertyName' has a value '$value' that cannot be retrieved using HTTP. Every code list value must be made available in an online registry. 

## Contextual XPath references

The namespace prefixes used as described in [README](./README.md#namespaces).

Abbreviation                                               |  XPath expression
---------------------------------------------------------- | -------------------------------------------------------------------------
relatedZone <a name ="relatedZone"></a>	| //schema-element(am:ManagementRestrictionOrRegulationZone)/am:relatedZone/@xlink:href
plan <a name ="plan"></a>	| //schema-element(am:ManagementRestrictionOrRegulationZone)/am:plan/@xlink:href
legalBasis <a name ="legalBasis"></a>	| //schema-element(am:ManagementRestrictionOrRegulationZone)/am:legalBasis/@xlink:href
